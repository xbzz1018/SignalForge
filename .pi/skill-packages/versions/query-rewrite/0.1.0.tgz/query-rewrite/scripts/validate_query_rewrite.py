#!/usr/bin/env python3
"""Validate a QuantPilot query rewrite artifact without network or file writes."""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any


SYMBOL_PATTERN = re.compile(r"^(?:6|0|3|5)\d{5}$")
VALID_STATUSES = {"ready", "partial", "needs_clarification"}
VALID_OUTPUT_INTENTS = {"dashboard", "answer"}


def parse_input(value: str) -> Any:
    if value == "-":
        source = sys.stdin.read()
    else:
        candidate = Path(value)
        source = candidate.read_text(encoding="utf-8") if candidate.is_file() else value
    return json.loads(source)


def validate(payload: Any) -> dict[str, Any]:
    errors: list[str] = []
    warnings: list[str] = []
    if not isinstance(payload, dict):
        return {"valid": False, "errors": ["root must be an object"], "warnings": []}

    if payload.get("schemaVersion") != 1:
        errors.append("schemaVersion must equal 1")
    for field in ("originalQuery", "normalizedQuery", "rewrittenQuery", "capabilityHint"):
        if not isinstance(payload.get(field), str) or not payload[field].strip():
            errors.append(f"{field} must be a non-empty string")

    status = payload.get("status")
    if status not in VALID_STATUSES:
        errors.append("status must be ready, partial, or needs_clarification")
    confidence = payload.get("confidence")
    if not isinstance(confidence, (int, float)) or isinstance(confidence, bool) or not 0 <= confidence <= 1:
        errors.append("confidence must be a number between 0 and 1")
    if payload.get("outputIntent") not in VALID_OUTPUT_INTENTS:
        errors.append("outputIntent must be dashboard or answer")

    list_fields = (
        "targetCandidates",
        "resolvedSymbols",
        "unresolvedTargets",
        "ambiguousTargets",
        "issues",
    )
    for field in list_fields:
        if not isinstance(payload.get(field), list):
            errors.append(f"{field} must be an array")

    resolved = payload.get("resolvedSymbols") if isinstance(payload.get("resolvedSymbols"), list) else []
    symbols: list[str] = []
    for index, item in enumerate(resolved):
        if not isinstance(item, dict):
            errors.append(f"resolvedSymbols[{index}] must be an object")
            continue
        symbol = item.get("symbol")
        if not isinstance(symbol, str) or not SYMBOL_PATTERN.fullmatch(symbol):
            errors.append(f"resolvedSymbols[{index}].symbol must be a supported six-digit code")
        else:
            symbols.append(symbol)
        if not isinstance(item.get("query"), str) or not item["query"].strip():
            errors.append(f"resolvedSymbols[{index}].query must be a non-empty string")
        if not isinstance(item.get("name"), str) or not item["name"].strip():
            errors.append(f"resolvedSymbols[{index}].name must be a non-empty string")

    if len(symbols) != len(set(symbols)):
        errors.append("resolvedSymbols must not contain duplicate symbols")

    unresolved = payload.get("unresolvedTargets") if isinstance(payload.get("unresolvedTargets"), list) else []
    ambiguous = payload.get("ambiguousTargets") if isinstance(payload.get("ambiguousTargets"), list) else []
    broad_universe = payload.get("broadUniverse") is True
    if status == "ready" and (unresolved or ambiguous):
        errors.append("ready status cannot contain unresolved or ambiguous targets")
    if status == "ready" and not resolved and not broad_universe:
        errors.append("ready status requires resolvedSymbols or broadUniverse=true")
    if status == "partial" and (not resolved or not unresolved):
        errors.append("partial status requires both resolvedSymbols and unresolvedTargets")
    if status == "needs_clarification" and resolved and not unresolved and not ambiguous:
        warnings.append("needs_clarification contains resolved symbols but no unresolved or ambiguous target")

    return {
        "valid": not errors,
        "errors": errors,
        "warnings": warnings,
        "summary": {
            "status": status,
            "resolvedSymbolCount": len(resolved),
            "unresolvedTargetCount": len(unresolved),
            "ambiguousTargetCount": len(ambiguous),
        },
    }


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Validate a QuantPilot query_rewrite.json contract.",
    )
    parser.add_argument(
        "--input",
        required=True,
        help="JSON object, JSON file path, or - for stdin.",
    )
    args = parser.parse_args()
    try:
        payload = parse_input(args.input)
        result = validate(payload)
    except (OSError, json.JSONDecodeError) as error:
        result = {"valid": False, "errors": [str(error)], "warnings": []}

    stream = sys.stdout if result.get("valid") else sys.stderr
    print(json.dumps(result, ensure_ascii=False, separators=(",", ":")), file=stream)
    return 0 if result.get("valid") else 1


if __name__ == "__main__":
    raise SystemExit(main())
